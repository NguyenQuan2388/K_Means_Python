# Import các thư viện cần thiết
import cv2
from sklearn.cluster import KMeans
import os
import numpy as np
import pickle
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

#Đường dẫn data
c_data_path = "../data/Cars"

#Vì các ảnh có kích thước khác nhau nên ta đưa về chung 1 dạng để có thể xử lí
def get_feature(img):
    intensity = img.sum(axis=1)
    intensity = intensity.sum(axis=0) / (255 * img.shape[0] * img.shape[1])
    return intensity


def load_data(data_path=c_data_path):
    # try:
        with open('data.pickle', 'rb') as handle:
            X = pickle.load(handle)
        with open('label.pickle', 'rb') as handle:
            L = pickle.load(handle)
        return X, L
    # except:
    #     X = []              # List lưu dữ liệu ảnh
    #     L = []              # List lưu tên file
    #     #Đọc file sau đó gán vào X và L
    #     for file in os.listdir(data_path):
    #         c_x = get_feature(cv2.imread(os.path.join(data_path, file)))
    #         X.append(c_x)
    #         L.append(file)
    #     # Tạo 2 mảng
    #     X = np.array(X)
    #     L = np.array(L)
    #     #Lưu dữ liệu vào 2 file binary
    #     with open('data.pickle', 'wb') as handle:
    #         pickle.dump(X, handle, protocol=pickle.HIGHEST_PROTOCOL)
    #     with open('label.pickle', 'wb') as handle:
    #         pickle.dump(L, handle, protocol=pickle.HIGHEST_PROTOCOL)
    #
    #     return X,L

X,L = load_data()

wcss = [] #wcss: đo lường sự sai lệch đến điểm centerpoints
# Khởi tạo thuật toán kmean cluster với số cluster từ 1->10 và lưu giá trị
K = range(1,10)
for k in K:
    kmeanModel = KMeans(n_clusters=k)
    kmeanModel.fit(X)
    wcss.append(kmeanModel.inertia_)

# Vẽ biểu đồ wcss vs n_clusters
plt.figure(figsize=(16,8))
plt.plot(K, wcss, 'bx-')
plt.xlabel('k')
plt.ylabel('WCSS')
plt.title('The Elbow Method showing the optimal k')
plt.show()

#Thực hiện thuật toán K-Means với 5 clusters
kmeans = KMeans(n_clusters=5).fit(X)
#In ra tên file và clusters tương ứng
for i in range(len(kmeans.labels_)):
    print(kmeans.labels_[i]," - ", L[i])

#In ra tọa độ các tâm
print(kmeans.cluster_centers_)
#
# #In ra một vài mẫu thuộc các cụm
n_row = 6
n_col= 6
for i in range(5):
    _, axs = plt.subplots(n_row, n_col, figsize=(7, 7))
    axs = axs.flatten()
    for img, ax in zip(L[kmeans.labels_ == i][:36], axs):
        ax.imshow(mpimg.imread(os.path.join(c_data_path,img)))
    plt.tight_layout()
    plt.show()